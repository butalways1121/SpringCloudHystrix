package com.SpringCloudHystrixDashboardConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;

/**
 * Hello world!
 *
 */
@SpringBootApplication
//@EnableDiscoveryClient让服务使用eureka服务器 实现服务注册和发现
@EnableDiscoveryClient
//@EnableFeignClients启用feign客户端
@EnableFeignClients
//@EnableCircuitBreaker表示启动hystrix功能
@EnableCircuitBreaker
//启用 HystrixDashboard 断路器看板 相关配置
@EnableHystrixDashboard
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(App.class, args);
        System.out.println( "hystrix dashboard 服务启动..." );
    }
}
