package com.SpringCloudHystrixConsumer2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class ConsumerController {

	@RequestMapping("/hello")
	//@RequestParam主要用于将请求参数区域的数据映射到控制层方法的参数上,即获取前端参数
    public String index(@RequestParam String name) {
        return name+",Hello World";
    }
}
