package com.SpringCloudHystrixConsumer.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//如果调用某个服务失败（或者拒绝、超时等），会尝试调用其它机器上的该服务
@FeignClient(name= "springcloud-hystrix-consumer2",fallback = HelloRemoteHystrix.class)//服务熔断的时候返回fallback类中的内容,HelloRemoteHystrix.class就是HelloRemote的实现类，对应的实现方法就是此类的熔断时调用的方法
public interface HelloRemote {
	
    @RequestMapping(value = "/hello")
    public String hello(@RequestParam(value = "name") String name);
}
