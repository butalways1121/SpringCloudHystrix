package com.SpringCloudHystrixConsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringCloudHystrixConsumer.remote.HelloRemote;



//@RestController的作用等同于@Controller + @ResponseBody
@RestController
public class ConsumerController {
	
	@Autowired
    HelloRemote helloRemote;
	
    @RequestMapping("/hello/{name}")
	//可以将URL中占位符参数{xxx}绑定到处理器类的方法形参中@PathVariable("xxx")
    public String index(@PathVariable("name") String name) {
    	System.out.println("接受到请求参数:"+name+",进行转发到其他服务");
        return helloRemote.hello(name);
    }


}
