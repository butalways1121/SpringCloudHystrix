package com.SpringCloudHystrixConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

/**
 * Hello world!
 *
 */
@SpringBootApplication
//@EnableDiscoveryClient让服务使用eureka服务器 实现服务注册和发现
@EnableDiscoveryClient
//@EnableFeignClients启用feign客户端
@EnableFeignClients
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(App.class, args);
        System.out.println( "hystrix第一个消费者服务启动..." );
    }
}
